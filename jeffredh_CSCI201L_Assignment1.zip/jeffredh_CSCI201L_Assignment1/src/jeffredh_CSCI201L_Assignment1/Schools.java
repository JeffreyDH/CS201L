package jeffredh_CSCI201L_Assignment1;

import java.util.List;

public class Schools {
	private List<School> schools;

	/**
	 * @return the schools
	 */
	public List<School> getSchools() {
		return schools;
	}

	/**
	 * @param schools the schools to set
	 */
	public void setSchools(List<School> schools) {
		this.schools = schools;
	}
	public void addSchool(School school)
	{
		this.schools.add(school);
	}
	public boolean verify()
	{
		for(int i = 0; i < this.schools.size();i++)
		{
			if(!this.schools.get(i).verify())
				return false;
		}
		return true;
	}
	
	
	
}
