package jeffredh_CSCI201L_Assignment1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

public class Main {
	private static Menu menu;
	private static FileReader reader;
	private static Schools schools;
	
	public static void main (String [] args)
	{
		
		menu = new Menu();
		boolean run = true;
		boolean fileFound = false;
		Scanner scan = new Scanner(System.in);
		while(!fileFound)
		{
			System.out.println("What is the name of the input file");
			try {
				String input = scan.nextLine();
				reader = new FileReader(input);
				fileFound = true;
			}
			catch (FileNotFoundException fnfe){
				System.out.println("That file could not be found");
			}
		}
		try {
			Gson gson = new Gson();			
			schools = gson.fromJson(reader, Schools.class);
			schools.verify();
			menu.setSchools(schools);
		}
		catch(JsonParseException jpe){
			System.out.println("That is not a well-formed JSON file");
		}
		catch(NullPointerException npe)
		{
			System.out.println("That is not a well-formed JSON file");
		}
		
		menu.printCurrentMenu();
		while(run)
		{
			int option = menu.getUserOption(scan);
			menu.handleUserOption(option);
			if(menu.getRun() == false)
				run = false;
		}
	}
}
