package jeffredh_CSCI201L_Assignment1;

public class MeetingPeriod {
	private String day;
	private Time time;
	
	/**
	 * Constructor 
	 * @param day : string
	 * @param start : string
	 * @param end : string
	 */
	MeetingPeriod(String day, String start, String end)
	{
		setDay(day);
		setTime(start, end);
	}
	
	public Time getTime()
	{
		return this.time;
	}
	public String getDay()
	{
		return this.day;
	}
	public void setDay(String day)
	{
		this.day = day;
	}
	public void setTime(String start, String end)
	{
		this.time = new Time(start, end);
	}
	public String print()
	{
		return this.getDay() + " " + this.time.getStart() + "-" + this.time.getEnd();
	}
}
