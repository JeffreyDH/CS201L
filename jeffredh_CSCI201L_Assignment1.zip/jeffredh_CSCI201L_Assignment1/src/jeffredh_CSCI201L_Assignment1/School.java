package jeffredh_CSCI201L_Assignment1;

import java.util.List;

public class School {

	private String name;
	private List<Department> departments;
	
	School(String name, List<Department> departments)
	{
		setName(name);
		setDepartments(departments);
	}
	
	public void addDepartment(Department department)
	{
		this.departments.add(department);
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public List<Department> getDepartments()
	{
		return this.departments;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setDepartments(List<Department> departments)
	{
		this.departments = departments;
	}
	public boolean verify()
	{
		if(this.name.equals(null))
			return false;
		if(this.departments.isEmpty())
			return false;
		for(int i = 0; i < this.getDepartments().size(); i++)
		{
			if(!this.getDepartments().get(i).verify())
				return false;
		}
		return true;
	}
}
