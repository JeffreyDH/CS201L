package jeffredh_CSCI201L_Assignment1;

public class Time {
	private String start;
	private String end;
	
	Time(String start, String end)
	{
		setStart(start);
		setEnd(end);
	}
	
	/**
	 * @return String: start time of the class
	 */
	public String getStart() {
		return start;
	}
	/**
	 * @param start: string indicating the start time of the class
	 */
	public void setStart(String start) {
		this.start = start;
	}
	/**
	 * @return the end
	 */
	public String getEnd() {
		return end;
	}
	/**
	 * @param end: string indicating the end time of the class
	 */
	public void setEnd(String end) {
		this.end = end;
	}
	
}
