package jeffredh_CSCI201L_Assignment1;

import java.util.List;

public class Assistants {
	private List<StaffMemberID> staffMemberID;

	/**
	 * @return the staffMemberId
	 */
	public List<StaffMemberID> getStaffMemberId() {
		return this.staffMemberID;
	}
	/**
	 * @param staffMemberId the staffMemberId to set
	 */
	public void setStaffMemberId(List<StaffMemberID> staffId) {
		this.staffMemberID = staffId;
	}
	public void addStaffMemberId(StaffMemberID id)
	{
		staffMemberID.add(id);
	}
	public void print()
	{
		for(int i = 0; i < staffMemberID.size(); i++)
		{
			System.out.println(staffMemberID.get(i).getId());
		}
	}
}
