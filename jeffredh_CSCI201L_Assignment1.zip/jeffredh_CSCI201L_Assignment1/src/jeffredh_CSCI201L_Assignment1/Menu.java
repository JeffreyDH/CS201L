package jeffredh_CSCI201L_Assignment1;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Menu {
	
	private final static String INVALID_OPTION = "\nThat is an invalid option";
	private final static String USER_OPTION_QUERY = "What would you like to do?";
	private int numOptions;	
	private boolean isMainMenu;
	private boolean isSchoolMenu;
	private boolean isDeptMenu;
	private boolean isCoursesMenu;
	private boolean isCourseMenu;
	private boolean isStaffMenu;
	private boolean isMeetingMenu;
	private School currSchool;
	private Schools schools;
	private Department currDept;
	private Course currCourse;
	private List<Meeting> meetings;
	private boolean run;

	Menu()
	{
		this.setNumOptions(2);
		this.setIsMainMenu(true);
		this.setIsSchoolMenu(false);
		this.setIsDeptMenu(false);
		this.setIsCourseMenu(false);
		this.setIsCoursesMenu(false);
		this.setIsMeetingMenu(false);
		this.setIsStaffMenu(false);
		this.setRun(true);
	}
	
	public void setRun(boolean run)
	{
		this.run = run;
	}
	public boolean getRun() {
		return this.run;
	}
	public void setMeetings(List<Meeting> meetings)
	{
		this.meetings = meetings;
	}
	public List<Meeting> getMeetings()
	{
		return this.meetings;
	}
	public void setIsMainMenu(boolean isMain)
	{
		this.isMainMenu = isMain;
	}
	public boolean getIsMainMenu()
	{
		return this.isMainMenu;
	}
	
	public boolean getIsDeptMenu()
	{
		return this.isDeptMenu;
	}
	public void setIsDeptMenu(boolean isDeptMenu)
	{
		this.isDeptMenu = isDeptMenu;
	}
	/**
	 * @return the isSchoolMenu
	 */
	public boolean getIsSchoolMenu() {
		return isSchoolMenu;
	}

	/**
	 * @param isSchoolMenu the isSchoolMenu to set
	 */
	public void setIsSchoolMenu(boolean isSchoolMenu) {
		this.isSchoolMenu = isSchoolMenu;
	}

	/**
	 * @return the isCoursesMenu
	 */
	public boolean getIsCoursesMenu() {
		return isCoursesMenu;
	}

	/**
	 * @param isCoursesMenu the isCoursesMenu to set
	 */
	public void setIsCoursesMenu(boolean isCoursesMenu) {
		this.isCoursesMenu = isCoursesMenu;
	}

	/**
	 * @return the isCourseMenu
	 */
	public boolean getIsCourseMenu() {
		return isCourseMenu;
	}

	/**
	 * @param isCourseMenu the isCourseMenu to set
	 */
	public void setIsCourseMenu(boolean isCourseMenu) {
		this.isCourseMenu = isCourseMenu;
	}

	/**
	 * @return the isStaffMenu
	 */
	public boolean getIsStaffMenu() {
		return isStaffMenu;
	}

	/**
	 * @param isStaffMenu the isStaffMenu to set
	 */
	public void setIsStaffMenu(boolean isStaffMenu) {
		this.isStaffMenu = isStaffMenu;
	}

	/**
	 * @return the isMeetingMenu
	 */
	public boolean getIsMeetingMenu() {
		return isMeetingMenu;
	}

	/**
	 * @param isMeetingMenu the isMeetingMenu to set
	 */
	public void setIsMeetingMenu(boolean isMeetingMenu) {
		this.isMeetingMenu = isMeetingMenu;
	}

	public int getNumOptions()
	{
		return this.numOptions;
	}
	public void setNumOptions(int num)
	{
		this.numOptions = num;
	}
	/**
	 * @return the currSchool
	 */
	public School getCurrSchool() {
		return currSchool;
	}
	/**
	 * @param currSchool the currSchool to set
	 */
	public void setCurrSchool(School currSchool) {
		this.currSchool = currSchool;
	}
	/**
	 * @return the schools
	 */
	public Schools getSchools() {
		return schools;
	}
	/**
	 * @param schools the schools to set
	 */
	public void setSchools(Schools schools) {
		this.schools = schools;
	}
	/**
	 * @return the currDept
	 */
	public Department getCurrDept() {
		return currDept;
	}
	/**
	 * @param currDept the currDept to set
	 */
	public void setCurrDept(Department currDept) {
		this.currDept = currDept;
	}
	/**
	 * @return the currCourse
	 */
	public Course getCurrCourse() {
		return currCourse;
	}
	/**
	 * @param currCourse the currCourse to set
	 */
	public void setCurrCourse(Course currCourse) {
		this.currCourse = currCourse;
	}
	/**
	 * @param isMainMenu the isMainMenu to set
	 */
	public void setMainMenu(boolean isMainMenu) {
		this.isMainMenu = isMainMenu;
	}
	/**
	 * @param isSchoolMenu the isSchoolMenu to set
	 */
	public void setSchoolMenu(boolean isSchoolMenu) {
		this.isSchoolMenu = isSchoolMenu;
	}
	/**
	 * @param isDeptMenu the isDeptMenu to set
	 */
	public void setDeptMenu(boolean isDeptMenu) {
		this.isDeptMenu = isDeptMenu;
	}
	/**
	 * @param isCoursesMenu the isCoursesMenu to set
	 */
	public void setCoursesMenu(boolean isCoursesMenu) {
		this.isCoursesMenu = isCoursesMenu;
	}
	/**
	 * @param isCourseMenu the isCourseMenu to set
	 */
	public void setCourseMenu(boolean isCourseMenu) {
		this.isCourseMenu = isCourseMenu;
	}
	/**
	 * @param isStaffMenu the isStaffMenu to set
	 */
	public void setStaffMenu(boolean isStaffMenu) {
		this.isStaffMenu = isStaffMenu;
	}
	/**
	 * @param isMeetingMenu the isMeetingMenu to set
	 */
	public void setMeetingMenu(boolean isMeetingMenu) {
		this.isMeetingMenu = isMeetingMenu;
	}
	public void printMainMenu()
	{
		System.out.println("\t1) Display Schools");
		System.out.println("\t2) Exit");
		System.out.print(USER_OPTION_QUERY);
		this.numOptions = 2;
	}
	public void printSchools()
	{
		int i;
		System.out.println("Schools");
		for(i = 0; i < schools.getSchools().size(); i++)
		{
			System.out.println( "\t" + (i + 1) + ") " + this.schools.getSchools().get(i).getName());
			
		}
		System.out.println("\t" + (i+1) + ") Go to main menu");
		System.out.println( "\t" + (i+2) + ") Exit");
		System.out.println(USER_OPTION_QUERY);
		this.setNumOptions(i+2);
	}
	public void printDepartments()
	{
		System.out.println("Departments");
		int i;
		for(i = 0; i < currSchool.getDepartments().size(); i++)
		{
			System.out.println("\t"+ (i+1) + ") " + currSchool.getDepartments().get(i).print());
			
		}
		System.out.println("\t"+ (i+1) + ") Go to Schools Menu");
		System.out.println( "\t" + (i+2) + ") Exit");
		System.out.println(USER_OPTION_QUERY);
		this.setNumOptions(i+2);
	}
	public void printCourses()
	{
		System.out.println(getCurrDept().getPrefix() + " Courses");
		int i;
		for(i = 0; i < getCurrDept().getCourses().size(); i++)
		{
			Course curr = getCurrDept().getCourses().get(i);
			System.out.println("\t" + (i+1) + ") " + getCurrDept().getPrefix() + " " + curr.print());
		}
		System.out.println("\t" + (i+1) + ") Go to Departments Menu");
		System.out.println("\t" + (i+2) + ") Exit");
		System.out.println(USER_OPTION_QUERY);
		this.setNumOptions(i+2);
	
	}
	public void printCourse()
	{
		System.out.println(getCurrDept().getPrefix() + " " + getCurrCourse().print());
		System.out.println("\t1) View Course Staff");
		System.out.println("\t2) View Meeting Information");
		System.out.println("\t3) Go to " + currDept.getPrefix() + " Courses Menu");
		System.out.println("\t4) Exit");
		System.out.println(USER_OPTION_QUERY);
		this.setNumOptions(4);
	}
	public void printMeetings() 
	{
		System.out.println(getCurrDept().getPrefix() + " " + getCurrCourse().print());
		System.out.println("Meeting Information");
		System.out.println("\t1) Lecture");
		System.out.println("\t2) Lab");
		System.out.println("\t3) Quiz");
		System.out.println("\t4) " + getCurrDept().getPrefix() + " " + getCurrCourse().print() + " Menu");
		System.out.println("\t5) Exit");
		System.out.println(USER_OPTION_QUERY);
		this.setNumOptions(5);
	}
	public void printCourseStaff() 
	{
		String courseInfo = getCurrDept().getPrefix() + " " + getCurrCourse().print();
		System.out.println(courseInfo);
		System.out.println("Course Staff");
		System.out.println("\t1) View Instructors");
		System.out.println("\t2) View TAs");
		System.out.println("\t3) View CPs");
		System.out.println("\t4) View Graders");
		System.out.println("\t5) Go to " + courseInfo);
		System.out.println("\t6) Exit");
		System.out.println(USER_OPTION_QUERY);
		this.setNumOptions(6);
	}
	public int getUserOption(Scanner in)
	{
		boolean validInput = false;
		int option = -1;
		while(!validInput)
		{
			try {
				option = in.nextInt();
				if(option < 0 || option > this.getNumOptions())
				{
					System.out.println(INVALID_OPTION);
					this.printCurrentMenu();
					in.nextLine();
				}
				else
				{
					validInput = true;
				}
			}
			catch(InputMismatchException ime)
			{	
				System.out.println(INVALID_OPTION);
				this.printCurrentMenu();
				in.next();
			}

		}
		return option;
		
		
	}
	public void handleUserOption(int option)
	{
		if(this.getIsMainMenu())
		{
			if(!this.isPrevMenuOption(option) && !this.isExitOption(option))
			{
				this.setIsMainMenu(false);
				this.setIsSchoolMenu(true);
				this.printCurrentMenu();
			}
			else if(this.isExitOption(option)) {
				this.exit();
			}
			
		}
		else if(this.getIsSchoolMenu())
		{
			//return to previous menu option
			if(!this.isPrevMenuOption(option) && !this.isExitOption(option))
			{
				//subtract 1: to match the index of the schoolsList 
				option -=1;
				this.setCurrSchool(this.getSchools().getSchools().get(option));
				this.setIsDeptMenu(true);
				this.setIsSchoolMenu(false);
				this.setIsMainMenu(false);
				this.printCurrentMenu();
			}
			//chooses to return to main menu
			else if(this.isPrevMenuOption(option))
			{
				this.setIsSchoolMenu(false);
				this.setIsMainMenu(true);
				this.printCurrentMenu();
			}
			else if(this.isExitOption(option)) {
				this.exit();
			}
		}
		//if on the departments menu
		else if(this.getIsDeptMenu())
		{
			//chooses one of the departments
			//prints the departments courses
			if(!this.isPrevMenuOption(option) && !this.isExitOption(option))
			{
				option -= 1;
				this.setCurrDept(this.currSchool.getDepartments().get(option));
				this.setIsCoursesMenu(true);
				this.setIsDeptMenu(false);
				this.printCurrentMenu();
			}
			else if(this.isPrevMenuOption(option))
			{
				this.setIsCoursesMenu(false);
				this.setIsSchoolMenu(true);
				this.setIsDeptMenu(false);
				this.printCurrentMenu();
			}
			else if(this.isExitOption(option))
			{
				this.exit();
			}
		}
		//if on the courses menu
		else if(this.getIsCoursesMenu())	
		{
			//if a course is selected
			if(!this.isPrevMenuOption(option) && !this.isExitOption(option))
			{
				option -= 1;
				this.setCurrCourse(this.getCurrDept().getCourses().get(option));
				this.setIsCoursesMenu(false);
				this.setIsCourseMenu(true);
				this.printCurrentMenu();
			}
			else if(this.isPrevMenuOption(option))
			{
				this.setIsCoursesMenu(false);
				this.setIsDeptMenu(true);
				this.printCurrentMenu();
			}
			else if(this.isExitOption(option)) {
				this.exit();
			}
			
		}
		//if on a specific course's menu
		else if(this.getIsCourseMenu())
		{
			if(!this.isPrevMenuOption(option) && !this.isExitOption(option))
			{
				//1. staff menu (new menu)
				//2. meeting info (new menu)
				if(option == 1)
				{
					this.setIsStaffMenu(true);
					this.setIsCourseMenu(false);
					this.printCurrentMenu();

				}
				else if(option == 2)
				{
					this.setIsMeetingMenu(true);
					this.setIsCourseMenu(false);
					this.setMeetings(this.currCourse.getMeetings());
					this.printCurrentMenu();

				}
				this.setIsCourseMenu(false);
			}
			else if(this.isPrevMenuOption(option))
			{
				this.setIsCourseMenu(false);
				this.setIsCoursesMenu(true);
				this.printCurrentMenu();

			}
			else if(this.isExitOption(option))
			{
				this.exit();
			}				
		}
		//if on the course's meetings menu
		else if(this.getIsMeetingMenu())
		{
			if(!this.isPrevMenuOption(option) && !this.isExitOption(option))
			{
				//display information
				//no new menu needed
				//lecture
				if(option == 1)
				{
					if(!this.getCurrCourse().hasLecture())
					{
						System.out.println("No Lectures for selected course");
					}
					else
					{
						for(int i= 0; i < meetings.size(); i++)
						{
							if(meetings.get(i).isLecture())
								System.out.println(meetings.get(i).print(this.currCourse.getStaffMembers()));
						}
					}
					this.printCurrentMenu();
					
				}
				//lab
				else if(option == 2)
				{
					if(!this.getCurrCourse().hasLab())
					{
						System.out.println("No Labs for selected course");
					}
					else
					{
						for(int i= 0; i < meetings.size(); i++)
						{
							if(meetings.get(i).isLab())
								System.out.println(meetings.get(i).print(this.currCourse.getStaffMembers()));
						}
					}
					this.printCurrentMenu();
				}
				//quiz
				else if(option == 3)
				{
					if(!this.getCurrCourse().hasQuiz())
					{
						System.out.println("No Quizzes for selected course");
					}
					else
					{
						for(int i= 0; i < meetings.size(); i++)
						{
							if(meetings.get(i).isQuiz())
								System.out.println(meetings.get(i).print(this.currCourse.getStaffMembers()));
						}
					}
					this.printCurrentMenu();
				}
			}
			else if(this.isPrevMenuOption(option))
			{
				this.setIsCourseMenu(true);
				this.setIsMeetingMenu(false);
				this.printCurrentMenu();
			}
			else if(this.isExitOption(option)) {
				this.exit();
			}
		}
		//if on the staff's meetings menu
		else if(this.getIsStaffMenu())
		{
			if(!this.isPrevMenuOption(option) && !this.isExitOption(option))
			{
				//print the selected instructors info
				//display none available if there is no info
				//no new menu
				if(option == 1)
				{
					this.getCurrCourse().printStaffType("instructor");
				}
				else if(option == 2)
				{
					this.getCurrCourse().printStaffType("ta");
				}
				else if (option == 3) {
					this.getCurrCourse().printStaffType("cp");
				}
				else if(option == 4)
				{
					this.getCurrCourse().printStaffType("grader");
				}
				this.printCurrentMenu();
			}
			else if(this.isPrevMenuOption(option))
			{
				this.setIsStaffMenu(false);
				this.setIsCourseMenu(true);
				this.printCurrentMenu();
			}
			else if(this.isExitOption(option))
				this.exit();
		}
	}
	public void printCurrentMenu()
	{
		if(this.getIsMainMenu())
		{
			this.printMainMenu();
		}
		else if(this.getIsSchoolMenu())
		{
			this.printSchools();
		}
		else if(this.getIsDeptMenu())
		{
			this.printDepartments();
		}
		else if(this.getIsCoursesMenu())	
		{
			this.printCourses();
		}
		else if(this.getIsCourseMenu())
		{
			this.printCourse();
		}
		else if(this.getIsMeetingMenu())
		{
			this.printMeetings();
		}
		else if(this.getIsStaffMenu())
		{
			this.printCourseStaff();
		}	
	}
	private boolean isPrevMenuOption(int option)
	{
		if(option == this.getNumOptions()-1 && !this.getIsMainMenu())
			return true;
		else
			return false;
	}
	private boolean isExitOption(int option)
	{
		if(option == this.getNumOptions())
			return true;
		else
			return false;
	}
	private void exit()
	{
		System.out.println("\nThank you for using my program!");
		this.setRun(false);
	}
	
}
