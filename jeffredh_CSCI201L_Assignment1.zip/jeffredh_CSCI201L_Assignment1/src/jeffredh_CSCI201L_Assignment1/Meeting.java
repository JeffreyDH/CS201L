package jeffredh_CSCI201L_Assignment1;

import java.util.List;

public class Meeting {
	private String type;
	private String section;
	private String room;
	private List<MeetingPeriod> meetingPeriods;
	private List<StaffMemberID> assistants;
	
	/**
	 * @return the assistants
	 */
	public List<StaffMemberID> getAssistants() {
		return assistants;
	}
	/**
	 * @param assistants the assistants to set
	 */
	public void setAssistants(List<StaffMemberID> assistants) {
		this.assistants = assistants;
	}
	public void setType(String type)
	{
		this.type = type;
	}
	public void setSection(String section)
	{
		this.section = section;
	}
	public void setRoom(String room)
	{
		this.room = room;
	}
	public void setMeetingPeriods(List<MeetingPeriod> meetingPeriods)
	{
		this.meetingPeriods = meetingPeriods;
	}
	
	public String getType()
	{
		return this.type;
	}
	public String getSection()
	{
		return this.section;
	}
	public String getRoom()
	{
		return this.room;
	}
	public List<MeetingPeriod> getMeetingPeriods()
	{
		return this.meetingPeriods;
	}
	
	public void addMeetingPeriod(MeetingPeriod meetingPeriod)
	{
		meetingPeriods.add(meetingPeriod);
	}
	public boolean isLab()
	{
		if(this.type.equalsIgnoreCase("lab"))
			return true;
		return false;
	}
	public boolean isQuiz()
	{
		if(this.type.equalsIgnoreCase("Quiz"))
			return true;
		return false;
	}
	public boolean isLecture()
	{
		if(this.type.equalsIgnoreCase("lecture"))
			return true;
		return false;
	}
	public String print(List<StaffMember> staffMembers)
	{
		String info = this.getType() + " Meeting Information\n";
		info += "Section: " + this.getSection() +"\n";
		info += "Room: " + this.getRoom() + "\n";
		for(int i = 0; i < this.getMeetingPeriods().size(); i++)
		{
			info += "Meetings: " +  this.getMeetingPeriods().get(i).print();
			if(i != this.getMeetingPeriods().size()-1)
			{
				info += ", ";
			}
			else
				info += "\n";
		}
		info += "Assistants: ";
		if(this.getAssistants()!= null)
		{
			System.out.println("staffsize" + staffMembers.size());
			System.out.println(this.getAssistants().size());
			for(int i = 0; i < this.getAssistants().size(); i++)
			{
				StaffMember curr = this.matchAssitant(this.getAssistants().get(i), staffMembers);
				if(curr != null){
					info += curr.getName().print();
				}
				if(i != this.getAssistants().size()-1)
					info += ", ";
			}
		}
		else
			info += "N/A";
		
		return info;
		
	}
	public StaffMember matchAssitant(StaffMemberID id, List<StaffMember> staff)
	{
		for(int i = 0; i < staff.size(); i++)
		{
			if(staff.get(i).getId().equalsIgnoreCase(id.getId()))
			{
				return staff.get(i);
			}
		}
		return null;
	}
	public boolean verify()
	{
		if(this.getType().equals(null))
			return false;
		if(this.getSection().equals(null))
			return false;
		return true;
	}
}
