package jeffredh_CSCI201L_Assignment1;

import java.util.List;


public class StaffMember {
	private final static String INFO_NOT_AVAILABLE = "N/A";
	private String type;
	private String id;
	private Name name;
	private String email;
	private String image;
	private String phone;
	private String office;
	private List<OfficeHour> officeHours;

	StaffMember(String type, String id, Name name, String email, String image, String phone, 
				String office, List<OfficeHour> officeHours)
	{
		setType(type);
		setId(id);
		setName(name);
		setEmail(email);
		setImage(image);
		setPhone(phone);
		setOffice(office);
		setOfficeHours(officeHours);
	}
	


	public void setType(String type)
	{
		this.type = type;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public void setName(Name name)
	{
		this.name = name;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public void setImage(String image)
	{
		this.image = image;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public void setOffice(String office)
	{
		this.office = office;
	}
	public void setOfficeHours(List<OfficeHour> officeHours)
	{
		this.officeHours = officeHours;
	}
	
	
	public String getType()
	{
		return this.type;
	}
	public String getId()
	{
		return this.id;
	}
	public Name getName()
	{
		return this.name;
	}
	public String getEmail()
	{
		return this.email;
	}
	public String getImage()
	{
		return this.image;
	}
	public String getPhone()
	{
		return this.phone;
	}
	public String getOffice()
	{
		return this.office;
	}
	public List<OfficeHour> getOfficeHours()
	{
		return officeHours;
	}
	public boolean isInstructor()
	{
		if(this.type.equalsIgnoreCase("instructor"))
			return true;
		return false;
	}
	public boolean isTA()
	{
		if(this.type.equalsIgnoreCase("ta"))
			return true;
		return false;
	}
	public boolean isCP()
	{
		if(this.type.equalsIgnoreCase("cp"))
			return true;
		return false;
	}
	public boolean isGrader()
	{
		if(this.type.equalsIgnoreCase("grader"))
			return true;
		return false;
	}
	public String print()
	{
		String output;
		
		output = this.getType() + "\n";
		output += "Name: ";
		if(this.getName() != null)
			output += this.getName().print() + "\n";
		else {
			output += INFO_NOT_AVAILABLE + "\n";
		}
		output += "Email: ";
		if(this.getEmail()!= null)
			output += this.getEmail() + "\n";
		else
			output += INFO_NOT_AVAILABLE + "\n";
		
		output += "Image: ";
		if(this.getImage() != null)
			output += this.getImage() + "\n";
		
		output += "Phone: ";
		if(this.getPhone() != null)
			output += this.getPhone() + "\n";
		else
			output += INFO_NOT_AVAILABLE + "\n";
		
		output += "Office: ";
		if(this.getOffice() != null)
			output += this.getOffice() + "\n";
		else
			output += INFO_NOT_AVAILABLE + "\n";
		
		output += "Office Hours: ";
		if(this.getOfficeHours() != null)
		{
			for(int i = 0; i < this.getOfficeHours().size(); i++)
			{
				OfficeHour curr = this.getOfficeHours().get(i);
				output += curr.getDay() + " ";
				if(curr.getTime() != null)
					output += curr.getTime().getStart() + "-" + curr.getTime().getEnd();
				else
					output += "\n";
				if(i+1 != this.getOfficeHours().size()) 
				{
					output += ", ";
				}
			}
		}
		else
			output += INFO_NOT_AVAILABLE;

		return output;
	}
	public boolean verify()
	{
		if(this.getType().equals(null))
			return false;
		if(this.getId().equals(null))
			return false;
		if(this.getName().equals(null))
			return false;
		return true;
	}
	
}
