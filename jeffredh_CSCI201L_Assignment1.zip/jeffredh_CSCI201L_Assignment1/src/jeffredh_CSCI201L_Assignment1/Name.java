package jeffredh_CSCI201L_Assignment1;


public class Name {

	private String fname;
	private String lname;
	
	/**
	 * 
	 */
	Name(String fname, String lname)
	{
		setFirstName(fname);
		setLastName(lname);
	}
	public void setFirstName(String fName)
	{
		this.fname = fName;
	}
	/**
	 * 
	 */
	public void setLastName(String lName)
	{
		this.lname = lName;
	}
	/**
	 * @return string: first name
	 */
	public String getFirstName()
	{
		return this.fname;
	}
	/**
	 * @return string: last name
	 */
	public String getLastName()
	{
		return this.lname;
	}
	public String print()
	{
		return this.getFirstName() + " " + this.getLastName();
	}
}
