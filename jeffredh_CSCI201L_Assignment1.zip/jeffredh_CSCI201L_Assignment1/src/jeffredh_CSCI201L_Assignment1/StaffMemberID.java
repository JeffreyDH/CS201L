package jeffredh_CSCI201L_Assignment1;

public class StaffMemberID {
	private String staffMemberID;
	
	public void setId(String id)
	{
		this.staffMemberID = id;
	}
	public String getId()
	{
		return this.staffMemberID;
	}
	public boolean isEqual(String id)
	{
		if(!this.staffMemberID.equals(id))
			return false;
		return true;
	}
}
