package jeffredh_CSCI201L_Assignment1;

import java.util.List;

public class Department {
	private String longName;
	private String prefix;
	private List<Course> courses;
	
	
	public void addCourse(Course course)
	{
		this.courses.add(course);
	}
	public String getLongName()
	{
		return this.longName;
	}
	public String getPrefix()
	{
		return this.prefix;
	}
	public List<Course> getCourses()
	{
		return this.courses;
	}
	
	public void setLongName(String longName) 
	{
		this.longName = longName;
	}
	public void setPrefix(String prefix)
	{
		this.prefix = prefix;
	}
	public void setCourses(List<Course> courses)
	{
		this.courses = courses;
	}
	
	public String print()
	{
		return this.getLongName() +" (" +  this.getPrefix() + ")";
	}
	public boolean verify()
	{
		if(this.longName.equals(null))
			return false;
		if(this.prefix.equals(null))
			return false;
		if(this.getCourses().isEmpty())
			return false;
		for(int i = 0; i < this.getCourses().size(); i++) {
			if(!this.getCourses().get(i).verify())
				return false;
		}
		return true;
	}
}
