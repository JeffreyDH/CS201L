package jeffredh_CSCI201L_Assignment1;

import java.util.List;


public class Course {
	private int number;
	private String term;
	private int year;
	private List<StaffMember> staffMembers;
	private List<Meeting> meetings;
	
	/**
	 * Default constructor
	 */
	Course()
	{
		
	}
	
	/**
	 * Overloaded constructor
	 * @param number : integer- course number
	 * @param term : String of the term when the class will be held
	 * @param year : integer of the year in which the class will be held
	 * @param staffMembers : array of StaffMember objects
	 */
	Course(int number, String term, int year, List<StaffMember> staffMembers)
	{
		setNumber(number);
		setTerm(term);
		setYear(year);
		setStaffMembers(staffMembers);
	}
	
	/**
	 * 
	 */
	public void setNumber(int number)
	{
		this.number = number;
	}
	/**
	 * 
	 */
	public void setTerm(String term)
	{
		this.term = term;
	}
	/**
	 * 
	 */
	public void setYear(int year)
	{
		this.year = year;
	}
	/**
	 * 
	 */
	public void setStaffMembers(List<StaffMember> staffMembers)
	{
		this.staffMembers = staffMembers;
	}
	public void setMeetingPeriod(List<Meeting> meetings)
	{
		this.meetings = meetings;
	}
	/**
	 * @return the number
	 */
	public int getNumber() {
		return this.number;
	}
	/**
	 * @return the term
	 */
	public String getTerm() {
		return this.term;
	}
	/**
	 * @return the year
	 */
	public int getYear() {
		return this.year;
	}
	/**
	 * @return the staffMembers
	 */
	public List<StaffMember> getStaffMembers() 
	{
		return this.staffMembers;
	}
	public List<Meeting> getMeetings()
	{
		return this.meetings;
	}
	
	public String print()
	{
		return this.getNumber() + " "+ this.getTerm() + " " + this.getYear();
	}
	public boolean hasLab()
	{
		for(int i = 0; i < this.getMeetings().size(); i++)
		{
			if(this.getMeetings().get(i).isLab())
				return true;
		}
		return false;
	}
	public boolean hasLecture()
	{
		for(int i = 0; i < this.getMeetings().size(); i++)
		{
			if(this.getMeetings().get(i).isLecture())
				return true;
		}
		return false;
	}
	public boolean hasQuiz()
	{
		for(int i = 0; i < this.getMeetings().size(); i++)
		{
			if(this.getMeetings().get(i).isQuiz())
				return true;		
		}
		return false;
	}
	public void printStaffType(String type)
	{
		for(int i = 0; i < this.staffMembers.size(); i++)
		{
			if(this.staffMembers.get(i).getType().equalsIgnoreCase(type))
			{
				System.out.println(this.staffMembers.get(i).print());
			}
		}
	}
	public boolean verify()
	{
		if(this.getNumber() <= 0)
			return false;
		if(this.getTerm().equals(null))
			return false;
		if(this.getYear() == 0)
			return false;
		if(this.getStaffMembers().isEmpty())
			return false;
		for(int i = 0; i < this.getStaffMembers().size(); i++) {
			if(!this.getStaffMembers().get(i).verify())
				return false;
		}
		if(this.getMeetings().isEmpty())
			return false;
		for(int i = 0; i < this.getMeetings().size(); i++)
		{
			if(!this.getMeetings().get(i).verify())
				return false;
		}
		return true;
		//staffmembers must be valid
			
	}
	
}
